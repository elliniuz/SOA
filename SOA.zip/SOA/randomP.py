import numpy as np

def levy_flight(dimension, step_size=0.1):
    """تولید گام‌های پرش لوی"""
    beta = 1.5
    sigma = (np.math.gamma(1 + beta) * np.sin(np.pi * beta / 2) / 
             (np.math.gamma((1 + beta) / 2) * beta * 2**((beta - 1) / 2)))**(1 / beta)
    
    u = np.random.normal(0, sigma, size=dimension)
    v = np.random.normal(0, 1, size=dimension)
    step = u / (np.abs(v)**(1 / beta))
    return step * step_size

def random_numbers(shape):
    """تولید اعداد تصادفی استاندارد"""
    return np.random.rand(*shape)

# این بخش برای جلوگیری از خطا در صورت استفاده از توابع دیگر است
def get_random_vector(dim):
    return np.random.uniform(-1, 1, dim)
