import random
import numpy
import randomP
import math
import time
#================================================================
import sys
import os
class MockPkgResources:
    @staticmethod
    def resource_filename(package_or_requirement, resource_name):
        import opfunu
        base_path = os.path.dirname(opfunu.__file__)
        return os.path.join(base_path, resource_name)
sys.modules["pkg_resources"] = MockPkgResources()
#================================================================
import opfunu
import pytest
from numpy import abs, zeros, log10, where, arctanh, tanh
from numpy.random import uniform, standard_cauchy
import numpy as np
import matplotlib.pyplot as plt

class solution:
    def __init__(self):
        self.bestIndividual = []  # ذخیره بهترین موقعیت پیدا شده در فضا
        self.bestFitness = 0      # مقدار تابع هدف برای بهترین فرد (کمترین مقدار)
        self.convergence = []     # لیست مقادیر بهترین فیتنس در هر تکرار برای رسم نمودار
        self.optimizer = ""       # نام الگوریتم
        self.objfname = ""        # نام تابع هدف
        self.startTime = 0        # زمان شروع اجرا
        self.endTime = 0          # زمان پایان اجرا
        self.executionTime = 0    # مدت زمان کل اجرای الگوریتم
        self.lb = 0               # کران پایین جستجو
        self.ub = 0               # کران بالا جستجو
        self.dim = 0              # تعداد ابعاد (متغیرها)
        self.popnum = 0           # اندازه جمعیت
        self.maxiters = 0         # حداکثر تعداد تکرار


def SOA(objf, lb, ub, dim, PopSize, iters,function_name):

   #تنظیم ابعاد محدوده جستجو برای تمام ابعاد مسئله
   if not isinstance(lb, list): 
        lb = [lb] * dim
   if not isinstance(ub, list):
        ub = [ub] * dim

   #مقداردهی اولیه برای ذخیره فیتنس‌ها و موقعیت جمعیت
   Cost=numpy.full(PopSize,float("inf")) #record the fitness of all slime mold
   X = numpy.zeros((PopSize, dim))

   #توزیع اولیه ذرات در فضای جستجو (تولید تصادفی بین lb و ub)
   for i in range(dim):
        X[:, i] = numpy.random.uniform(0, 1, PopSize) * (ub[i] - lb[i]) + lb[i]

   #محاسبه مقدار تابع هدف (فیتنس) برای هر ذره و اطمینان از قرارگیری در محدوده مجاز
   for i in range(0,PopSize):
        X[i, :] = numpy.clip(X[i, :], lb, ub)
        Cost[i] = objf.evaluate(X[i, :])    

   #مرتب‌سازی جمعیت بر اساس فیتنس برای یافتن بهترین فرد
   SmellIndex = numpy.argsort(Cost)  # فقط اندیس‌ها را مرتب می‌کنیم (همزمان موقعیت و ترتیب مشخص می‌شود)
   Best_Cost = Cost[SmellIndex[0]]  # بهترین هزینه، اولین عضو هزینه‌ها بر اساس اندیس مرتب‌شده است
   Best_X = X[SmellIndex[0], :]     # بهترین ذره مستقیماً از روی اندیس برداشته می‌شود
   sorted_population = X[SmellIndex, :] # مرتب‌سازی کل جمعیت بر اساس همان اندیس‌ها

   Delta=  1e-5;                  #ثابت عددی بسیار کوچک تااز ناپایداری عددی جلوگیری شود

   s = solution()                 #ساخت جعبه نتایج

   timerStart = time.time()       #شروع زمان‌سنجی (عددی)
   s.startTime = time.strftime("%Y-%m-%d-%H-%M-%S")      #ثبت زمان شروع (متنی)
   print(f'Enhanced SOA is optimizing "{function_name}"')#اطلاع می‌دهد الگوریتم روی کدام تابع محک در حال اجراست.
   convergence_curve = numpy.zeros(iters)                #یک آرایه خالی می‌سازم تا بهترین رکورد هر تکرار را در آن ثبت کنیم
   
   for l in range(0, iters):
        mean_X = numpy.mean(X, axis=0)                   #میانگین همه جمعیت را حساب می‌کند
        distances = numpy.linalg.norm(X - mean_X, axis=1)#برای هر عضو جمعیت، فاصله آن تا میانگین را محاسبه می‌کند و خروجی را به صورت آرایه برمی گرداند
        closest_X = X[numpy.argmin(distances)]
        farthest_X = X[numpy.argmax(distances)]

        #حلقه روی هر عضو جمعیت
        for i in range(0, PopSize):
            Xnew   =  numpy.zeros(dim)#یک بردار صفر موقتی
            Z=Levy(dim)               #از تابع levy می آید
            ## the Secant equation
            id_1, id_2 = random.sample([_ for _ in range(PopSize) if _ != i], 2)
            dfXbest=(Best_Cost-Cost[i])/(2*random.random())  #شیب تقریبی بین بهترین جواب و عضو فعلی
            dfX=(Cost[id_1]-Cost[i])/(2*random.random())     #شیب تقریبی بین عضو تصادفی انتخاب‌شده و عضو فعلی
            Xnew = Best_X - (dfXbest * (X[i,:] - Best_X)) / (dfX - dfXbest + 1e-10)  
            #Xnew= Best_X-(dfXbest*(X[i,:]-Best_X))/(dfX-dfXbest)#secant equation(13)
            # proposed Local Ecape operator
            if numpy.random.rand() < numpy.random.rand():                 #دو عدد تصادفی مقایسه می‌شوند و با احتمال نصف، عملگر فرار اجرا می‌شود
                r=random.random()
                id_1, id_2 = random.sample([_ for _ in range(PopSize) if _ != i], 2)
                if numpy.random.rand() <0.5:
                    Xnew= X[i,:]+Z*(closest_X-numpy.random.uniform(lb,ub,dim))+r*(farthest_X-X[id_1,:])#Eq(17)
                else:
                    Xnew =Best_X+Z*(Xnew-X[i,:])+numpy.random.rand()*(X[i,:]-X[id_2,:])                #Eq(18) 
           
            Xnew = _mutation__(X[i, :], Xnew,dim,0.2,lb,ub)# روی جواب جدید اعمال می‌شود mutation
            Xnew=numpy.clip(Xnew, lb, ub)#جلوی خروج جواب از فضای مسئله را می‌گیرد و مؤلفه‌های  را داخل بازه مجاز نگه می‌دارد      
            Xnew_Cost=objf.evaluate(Xnew)#اتابع هدف روی جواب جدید اجرا می‌شود
            if Cost[i] > Xnew_Cost:      #اگر هزینه جواب جدید از هزینه جواب فعلی کمتر باشد، جواب جدید بهتر است
                Cost[i]=Xnew_Cost        #هزینه عضو فعلی جمعیت را با هزینه جواب جدید به‌روزرسانی می‌کند 
                X[i,:]=Xnew              #خود جواب جدید جایگزین جواب قبلی همان عضو جمعیت می‌شود
                if Cost[i]<Best_Cost:    #اگر این جواب جدید از بهترین جواب کل تا این لحظه هم بهتر باشد، باید رکورد بهترین جواب هم عوض شود
                    Best_X=X[i,:]        #بهترین بردار جواب کل تا این لحظه را با این جواب جدید جایگزین می‌کند
                    Best_Cost=Cost[i]    #هزینه بهترین جواب کل را هم به‌روزرسانی می‌کند
         # if l % 1 == 0:
         # print(["At iteration " + str(l)+ " the best fitness is "+ str(Best_Cost)])
        convergence_curve[l] = Best_Cost         #مقدار بهترین هزینه در تکرار فعلی داخل آرایه همگرایی ذخیره می‌شود برای رسم نمودار همگرایی 
   timerEnd = time.time()                        #زمان پایان اجرای الگوریتم ثبت می‌شود 
   s.endTime = time.strftime("%Y-%m-%d-%H-%M-%S")#زمان پایان به صورت رشته‌ی خوانا ذخیره می‌شود
   s.executionTime = timerEnd - timerStart       #مدت زمان اجرای الگوریتم حساب می‌شود
   s.convergence = convergence_curve             #منحنی همگرایی در خروجی ذخیره می‌شود
   s.optimizer = "SOA"                           #نام الگوریتم داخل خروجی ثبت می‌شود
   s.objfname = function_name                    #نام تابع هدف مسئله در خروجی ذخیره می‌شود
   s.best = Best_Cost                            #بهترین مقدار به‌دست‌آمده داخل خروجی ثبت می‌شود
   return s                                      #خروجی نهایی الگوریتم شامل بهترین جواب، بهترین هزینه، زمان اجرا و منحنی همگرایی، برگردانده می‌شود

def Levy(dim):
    beta=1.5
    sigma=(math.gamma(1+beta)*math.sin(math.pi*beta/2)/(math.gamma((1+beta)/2)*beta*2**((beta-1)/2)))**(1/beta)#صورت 
    u= 0.01*numpy.random.randn(dim)*sigma       #بردار تصادفی نرمال استاندارد (صورت کسر)  
    v = numpy.random.randn(dim)                 #بردار تصادفی نرمال (مخرج کسر)
    zz = numpy.power(numpy.absolute(v),(1/beta))#مخرج
    step = numpy.divide(u,zz)                   #بردار نهایی
    return step

def _mutation__(current_pos, new_pos,dim,crossover_ratio,lb,ub):
    pos_new = numpy.where(numpy.random.uniform(0, 1, dim) < crossover_ratio, current_pos, new_pos)
    return pos_new
#current_pos: جواب فعلی عضو جمعیت
#new_pos: جواب پیشنهادی
#dim: تعداد ابعاد
#crossover_ratio: نرخ نگهداشتن از جواب فعلی (اینجا ۰٫۲)
#lb, ub: حدود بازه
#برای هر بُعد یک عدد تصادفی در بازه [۰,۱) تولید میکند و اگر کمتر از نرخ باشد،آن بعد از جواب فعلی گرفته کی شود و در غیر اینصورت از جواب پیشنهادی

NumOfRuns = 1
dim = 20
PopSize = 30
iters = 1000
lb = -100
ub = 100

benchmark_functions = [
    ("f1", opfunu.cec_based.F12021),
    ("f2", opfunu.cec_based.F22021),
    ("f3", opfunu.cec_based.F32021),
    ("f4", opfunu.cec_based.F42021),
    ("f5", opfunu.cec_based.F52021),
    ("f6", opfunu.cec_based.F62021),
    ("f7", opfunu.cec_based.F72021),
    ("f8", opfunu.cec_based.F82021),
    ("f9", opfunu.cec_based.F92021),
    ("f10", opfunu.cec_based.F102021),
]

all_mean_fitness = []
all_std_fitness = []
all_best_fitness_matrix = []
function_names = []

for function_name, func_class in benchmark_functions:
    print(f"\n================ Running on {function_name.upper()} ================")
    problem = func_class(ndim=dim)

    best_fitness_values = []
    convergence_curves = []

    for run in range(NumOfRuns):
        print(f"Run {run + 1}/{NumOfRuns}")
        s = SOA(problem, lb, ub, dim, PopSize, iters, function_name)
        best_fitness_values.append(s.best)
        convergence_curves.append(s.convergence)

    all_best_fitness_matrix.append(best_fitness_values)
    all_mean_fitness.append(np.mean(best_fitness_values))
    all_std_fitness.append(np.std(best_fitness_values))
    function_names.append(function_name.upper())

# =============== linear plot ==============

    plt.figure(figsize=(10, 6))
    
    all_values = [val for sublist in convergence_curves for val in sublist]
    y_min, y_max = min(all_values), max(all_values)
    padding = (y_max - y_min) * 0.1 
    
    for run in range(NumOfRuns):
        plt.plot(convergence_curves[run], label=f'Run {run + 1}')
    
    plt.ylim(y_min - padding, y_max + padding)
    plt.xlabel('Iteration')
    plt.ylabel('Best Fitness')
    plt.title(f'SOA Convergence Curves on {function_name.upper()}')
    plt.legend()
    plt.grid(True)
    plt.savefig(f'SOA_Convergence_{function_name}.png')
    plt.close()

# =============== log plot ===============
    
    plt.figure(figsize=(10, 6))
    for run in range(NumOfRuns):
        log_data = np.abs(np.array(convergence_curves[run])) + 1e-16
        plt.plot(log_data, label=f'Run {run + 1}')
    
    plt.yscale('log')
    plt.xlabel('Iteration')
    plt.ylabel('Best Fitness')
    plt.title(f'SOA Log-Convergence on {function_name.upper()}')
    plt.legend()
    plt.grid(True, which="both", ls="-", alpha=0.3)
    plt.savefig(f'SOA_Log_Convergence_{function_name}.png')
    plt.close()
#===========================================
#plot box
#===========================================
plt.figure(figsize=(10, 6))
plt.boxplot(all_best_fitness_matrix, orientation='vertical', patch_artist=True)

plt.xticks(ticks=range(1, len(function_names) + 1), labels=function_names)

plt.ylabel('Best Fitness')
plt.title('SOA Performance Comparison Across All CEC 2021 Benchmarks')
plt.grid(True)
plt.savefig('SOA_All_Functions_Boxplot.png')
plt.show()
plt.close() 
# ==========================================
# table
# ==========================================
theoretical_optima = {
    "F1": 100.0, "F2": 1100.0, "F3": 700.0, "F4": 600.0,
    "F5": 800.0, "F6": 1000.0, "F7": 300.0, "F8": 900.0,
    "F9": 200.0, "F10": 500.0
}

print("\n" + "="*75)
print(f"{'Function':<10} | {'Optimum':<10} | {'Mean Fitness':<20} | {'Std Dev':<15}")
print("="*75)

for name, mean_val, std_val in zip(function_names, all_mean_fitness, all_std_fitness):
    optimum = theoretical_optima.get(name, 0.0)
    print(f"{name:<10} | {optimum:<10.1f} | {mean_val:<20.4e} | {std_val:<15.4e}")

print("="*75)
